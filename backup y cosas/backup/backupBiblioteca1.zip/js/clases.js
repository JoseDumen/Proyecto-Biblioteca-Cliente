//Function Biblioteca

"use strict";

function Biblioteca(){
    this.usuarios = [];
    this.articulos = [];
    this.prestamos = [];
}

Biblioteca.prototype.optionsLibros = function(){

    let sOptions = '<option value="-1">Ninguno</option>';

    for(let articulo of this.articulos){
        if (articulo.prestado == false){ // && articulo instanceof Libro){
            sOptions += '<option value="' + articulo.idArticulo + '">' + articulo.nombre + '</option>';
        }
    }

    return sOptions;
}

Biblioteca.prototype.optionsDVD = function(){

    let sOptions = '<option value="-1">Ninguno</option>';

    for(let articulo of this.articulos){ 
        if (articulo.prestado == false){ // && articulo instanceof DVD
            sOptions += '<option value="' + articulo.idArticulo + '">' + articulo.nombre + '</option>';
        }
    }

    return sOptions;
}



//Clase Usuario

class Usuario {
constructor(iIdUsuario, sNombre, sApellidos, iTelefono) {
    this.idUsuario = iIdUsuario;
    this.nombre = sNombre;
    this.apellidos = sApellidos;
    this.telefono = iTelefono;
}


get toHTMLRow(){
    let sFila = "<tr>";
    sFila += "<td>" + this.idUsuario + "</td>";
    sFila += "<td>" + this.nombre + "</td>";
    sFila += "<td>" + this.apellidos + "</td>";
    sFila += "<td>" + this.telefono + "</td>";
}
}

// Clase Articulo

class Articulo
{
    constructor(iIdArticulo, sTitulo, bPrestado)
    {
        this.articulo = iIdArticulo;
        this.titulo = sTitulo;
        this.prestado = bPrestado;
    }

    get toHTMLRow()
    {
        let sFila = "<tr>";
        sFila += "<td>" + this.articulo + "</td>";
        sFila += "<td>" + this.titulo + "</td>";
        if(this.prestado == true)
        sFila += "<td>Sí</td></tr>";
        else
        sFila += "<td>No</td></tr>";
    }
}

//Clase Libro

class Libro extends Articulo
{
    constructor(iIdArticulo, sTitulo ,nAutor, iPaginas, bPrestado)
    {
        super(iIdArticulo, sTitulo);
        this.autor = nAutor;
        this.paginas = iPaginas;
        this.prestado = bPrestado;

    }

    get toHTMLRow()
    {
        let sFila = "<tr>";
        sFila += "<td>" + this.articulo + "</td>";
        sFila += "<td>" + this.titulo + "</td>";
        sFila += "<td>" + this.autor + "</td>";
        sFila += "<td>" + this.paginas + "</td>";
        if(this.prestado == true)
        sFila += "<td>Sí</td></tr>";
        else
        sFila += "<td>No</td></tr>";
    }
}

//Clase DVD

class DVD extends Articulo
{
    constructor(iIdArticulo,sTitulo,dtFechaEstreno,bSubtitulada,bPrestado) {
    super(iIdArticulo,sTitulo);
    this.fechaEstreno = dtFechaEstreno;
    this.subtitulada = bSubtitulada;
    this.prestado = bPrestado;
}

 get toHTMLRow(){
    let sFila = "<tr>";
    sFila += "<td>" + this.idArticulo + "</td>";
    sFila += "<td>" + this.titulo + "</td>";
    sFila += "<td>" + this.fechaEstreno + "</td>";
    sFila += "<td>" + this.subtitulada + "</td>";
    if(this.prestado == true)
    sFila += "<td>Sí</td></tr>";
    else
    sFila += "<td>No</td></tr>";
}
    
}

//Clase Prestamo

class Prestamo{
    constructor(iIdPrestamo, articulos, oUsuario, dtFechaInicio, dtFechaFin){
        this.idPrestamo = iIdPrestamo;
        this.articulos = articulos;
        this.usuario = oUsuario;
        this.fechaInicio = dtFechaInicio;
        this.fechaFin = dtFechaFin;
    }

    get toHTMLRow(){
        let sFila = "<tr>";
        sFila += "<td>" + this.idPrestamo + "</td>";
        for(let i = 0; i<this.articulos.length;i++){
            sFila += "<td>" + this.articulos[i].titulo + "</td><br>";    
        }
        sFila += "<td>" + this.articulos + "</td>";
        sFila += "<td>" + this.usuario.nombre + "</td>";
        sFila += "<td>" + this.fechaInicio + "</td>";
        sFila += "<td>" + this.fechaFin + "</td></tr>";
    }
}






